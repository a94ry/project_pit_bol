// Простое SPA приложение Journal (HTML + JS only)
// Data model: array of records {id, FIO, Class, Subject, Grade}
let records = [];
let editingId = null;

const $ = sel => document.querySelector(sel);
const $$ = sel => Array.from(document.querySelectorAll(sel));

function uid(){ return Date.now().toString(36) + Math.random().toString(36).slice(2,6); }

/* --- Tabs --- */
$$('.tab').forEach(t => t.addEventListener('click', e => {
  $$('.tab').forEach(x=>x.classList.remove('active'));
  t.classList.add('active');
  const tab = t.dataset.tab;
  $$('.panel').forEach(p => p.classList.remove('active'));
  $('#' + tab).classList.add('active');
}));

/* --- File loading --- */
document.getElementById('parseFileBtn').addEventListener('click', () => {
  const fi = document.getElementById('fileInput');
  if(!fi.files || fi.files.length===0){ alert('Выберите файл'); return; }
  const f = fi.files[0];
  const name = f.name.toLowerCase();
  if(name.endsWith('.xlsx')) readXLSX(f);
  else readTextLike(f);
});

function readTextLike(file){
  const reader = new FileReader();
  reader.onload = e => {
    const text = e.target.result;
    // try parse CSV with PapaParse
    const res = Papa.parse(text.trim(), {header:true, skipEmptyLines:true});
    if(res && res.data && res.data.length){
      const parsed = res.data.map(row => normalizeRow(row));
      pushRecords(parsed);
      renderLoadedTable(parsed);
      fillFilters();
    } else {
      alert('Не удалось распарсить CSV/TXT файл. Убедитесь в формате.');
    }
  };
  reader.readAsText(file, 'utf-8');
}

function readXLSX(file){
  const reader = new FileReader();
  reader.onload = e => {
    const data = new Uint8Array(e.target.result);
    const workbook = XLSX.read(data, {type:'array'});
    const first = workbook.Sheets[workbook.SheetNames[0]];
    const json = XLSX.utils.sheet_to_json(first, {defval:''});
    const parsed = json.map(r => normalizeRow(r));
    pushRecords(parsed);
    renderLoadedTable(parsed);
    fillFilters();
  };
  reader.readAsArrayBuffer(file);
}

function normalizeRow(row){
  // Accept various header names by lowercasing keys
  const keyMap = {};
  Object.keys(row).forEach(k => keyMap[k.toLowerCase().trim()] = k);
  const fio = row[keyMap['fio'] || keyMap['фио'] || 'FIO'] || row[keyMap['name']] || '';
  const cls = row[keyMap['class'] || keyMap['класс'] || 'Class'] || '';
  const subj = row[keyMap['subject'] || keyMap['предмет'] || 'Subject'] || '';
  const grade = row[keyMap['grade'] || keyMap['оценка'] || 'Grade'] || '';
  return { id: uid(), FIO: String(fio).trim(), Class: String(cls).trim(), Subject: String(subj).trim(), Grade: String(grade).trim() };
}

function pushRecords(arr){
  arr.forEach(r => {
    if(r.FIO && r.Subject && r.Grade !== '') records.push({...r});
  });
  alert('Добавлено записей: ' + arr.length);
}

/* --- Render loaded preview --- */
function renderLoadedTable(data){
  const thead = $('#loadedTable thead');
  const tbody = $('#loadedTable tbody');
  thead.innerHTML = '';
  tbody.innerHTML = '';
  if(!data || data.length===0) return;
  const keys = Object.keys(data[0]).filter(k => k !== 'id');
  const tr = document.createElement('tr');
  keys.forEach(k => { const th=document.createElement('th'); th.textContent=k; tr.appendChild(th); });
  thead.appendChild(tr);
  data.forEach(row => {
    const tr = document.createElement('tr');
    keys.forEach(k => {
      const td=document.createElement('td'); td.textContent = row[k] ?? '';
      tr.appendChild(td);
    });
    tbody.appendChild(tr);
  });
}

/* --- Journal (editor) --- */
function refreshJournalTable(){
  const tbody = $('#journalTable tbody');
  tbody.innerHTML = '';
  records.forEach((r, idx) => {
    const tr = document.createElement('tr');
    tr.innerHTML = `<td>${idx+1}</td><td>${r.FIO}</td><td>${r.Class}</td><td>${r.Subject}</td><td>${r.Grade}</td>
      <td>
        <button class="selectBtn" data-id="${r.id}">Выбрать</button>
        <button class="delBtn" data-id="${r.id}">Удалить</button>
      </td>`;
    tbody.appendChild(tr);
  });
  // attach events
  $$('.selectBtn').forEach(b => b.addEventListener('click', e => selectRecord(e.target.dataset.id)));
  $$('.delBtn').forEach(b => b.addEventListener('click', e => deleteRecord(e.target.dataset.id)));
}

function selectRecord(id){
  const r = records.find(x=>x.id===id);
  if(!r) return;
  $('#fio').value = r.FIO;
  $('#class').value = r.Class;
  $('#subject').value = r.Subject;
  $('#grade').value = r.Grade;
  editingId = id;
  $('#updateBtn').disabled = false;
  document.querySelector('[data-tab="edit"]').click();
}

function deleteRecord(id){
  if(!confirm('Удалить запись?')) return;
  records = records.filter(x=>x.id!==id);
  refreshJournalTable();
  fillFilters();
}

/* buttons */
$('#addBtn').addEventListener('click', () => {
  const r = { id: uid(), FIO: $('#fio').value.trim(), Class: $('#class').value.trim(), Subject: $('#subject').value.trim(), Grade: $('#grade').value.trim() };
  if(!r.FIO || !r.Subject || r.Grade==='' ){ alert('Заполните ФИО, предмет и оценку.'); return; }
  records.push(r);
  refreshJournalTable();
  clearEditor();
  fillFilters();
});

$('#updateBtn').addEventListener('click', () => {
  if(!editingId) return;
  const r = records.find(x=>x.id===editingId);
  if(!r) return;
  r.FIO = $('#fio').value.trim();
  r.Class = $('#class').value.trim();
  r.Subject = $('#subject').value.trim();
  r.Grade = $('#grade').value.trim();
  editingId = null;
  $('#updateBtn').disabled = true;
  refreshJournalTable();
  clearEditor();
  fillFilters();
});

$('#clearBtn').addEventListener('click', clearEditor);

function clearEditor(){
  $('#fio').value=''; $('#class').value=''; $('#subject').value=''; $('#grade').value='';
  editingId = null; $('#updateBtn').disabled = true;
}

/* export */
function download(filename, text){
  const a=document.createElement('a');
  a.href = URL.createObjectURL(new Blob([text], {type:'text/plain;charset=utf-8'}));
  a.download = filename;
  document.body.appendChild(a); a.click(); a.remove();
}

$('#exportJsonBtn').addEventListener('click', () => {
  const js = JSON.stringify(records, null, 2);
  download('journal.json', js);
});

$('#exportCsvBtn').addEventListener('click', () => {
  if(records.length===0){ alert('Нет данных'); return; }
  const headers = ['FIO','Class','Subject','Grade'];
  const lines = [headers.join(',')].concat(records.map(r => `${csvEscape(r.FIO)},${csvEscape(r.Class)},${csvEscape(r.Subject)},${csvEscape(r.Grade)}`));
  download('journal_export.csv', lines.join('\n'));
});

function csvEscape(s){ if(s==null) return ''; return '"'+String(s).replace(/"/g,'""')+'"'; }

/* --- Stats (table) --- */
function fillFilters(){
  const classes = Array.from(new Set(records.map(r=>r.Class).filter(Boolean))).sort();
  const subjects = Array.from(new Set(records.map(r=>r.Subject).filter(Boolean))).sort();
  const statClass = $('#statClass'); const statSubject = $('#statSubject');
  const chartClass = $('#chartClass'); const chartSubject = $('#chartSubject');
  [statClass, statSubject, chartClass, chartSubject].forEach(sel => {
    const isClass = sel.id.toLowerCase().includes('class');
    const values = isClass ? classes : subjects;
    // preserve currently selected
    const cur = sel.value;
    sel.innerHTML = '<option value="__all__">Все</option>';
    values.forEach(v => { const o = document.createElement('option'); o.value=v; o.textContent=v; sel.appendChild(o); });
    if([...sel.options].some(o=>o.value===cur)) sel.value = cur;
  });
}

$('#computeStatsBtn').addEventListener('click', () => {
  const cls = $('#statClass').value;
  const subj = $('#statSubject').value;
  const filtered = records.filter(r => (cls==='__all__' || r.Class===cls) && (subj==='__all__' || r.Subject===subj));
  const grouped = groupBySubjectAndClass(filtered);
  renderStatsTable(grouped);
});

function groupBySubjectAndClass(arr){
  // produce stats per class+subject and per subject overall
  const byClassSub = {};
  const bySubject = {};
  arr.forEach(r => {
    const g = Number(String(r.Grade).replace(',', '.'));
    const cls = r.Class || '__no_class__'; const subj = r.Subject || '__no_subject__';
    byClassSub[cls] = byClassSub[cls] || {};
    byClassSub[cls][subj] = byClassSub[cls][subj] || [];
    byClassSub[cls][subj].push(g);
    bySubject[subj] = bySubject[subj] || [];
    bySubject[subj].push(g);
  });
  return { byClassSub, bySubject };
}

function statsFromArray(arr){
  if(!arr || arr.length===0) return null;
  const sorted = arr.slice().sort((a,b)=>a-b);
  const mean = (arr.reduce((s,v)=>s+Number(v),0))/arr.length;
  const median = (sorted.length%2===1)? sorted[(sorted.length-1)/2] : (sorted[sorted.length/2 -1]+sorted[sorted.length/2])/2;
  // counts for each grade (rounded to nearest integer if needed)
  const counts = {};
  sorted.forEach(v => {
    const key = String(v);
    counts[key] = (counts[key]||0)+1;
  });
  return {mean,median,count:arr.length,counts};
}

function renderStatsTable(grouped){
  const container = $('#statsResult');
  container.innerHTML = '';
  // per class and subject
  const h1 = document.createElement('h3'); h1.textContent = 'По классам и предметам'; container.appendChild(h1);
  const table1 = document.createElement('table');
  table1.innerHTML = `<thead><tr><th>Класс</th><th>Предмет</th><th>Среднее</th><th>Медиана</th><th>Количество</th><th>Распределение (оценка:кол-во, %)</th></tr></thead><tbody></tbody>`;
  const tbody1 = table1.querySelector('tbody');
  Object.keys(grouped.byClassSub).sort().forEach(cls => {
    Object.keys(grouped.byClassSub[cls]).sort().forEach(subj => {
      const arr = grouped.byClassSub[cls][subj].filter(v => v !== '' && !isNaN(v)).map(Number);
      const st = statsFromArray(arr);
      const tr = document.createElement('tr');
      if(!st){ tr.innerHTML = `<td>${cls}</td><td>${subj}</td><td>-</td><td>-</td><td>0</td><td>-</td>`; tbody1.appendChild(tr); return; }
      const dist = Object.entries(st.counts).map(([g,c])=> `${g}:${c}, ${((c/st.count)*100).toFixed(1)}%`).join('; ');
      tr.innerHTML = `<td>${cls}</td><td>${subj}</td><td>${st.mean.toFixed(2)}</td><td>${st.median}</td><td>${st.count}</td><td>${dist}</td>`;
      tbody1.appendChild(tr);
    });
  });
  container.appendChild(table1);

  // overall per subject
  const h2 = document.createElement('h3'); h2.textContent = 'По предметам (всего по всем классам)'; container.appendChild(h2);
  const table2 = document.createElement('table');
  table2.innerHTML = `<thead><tr><th>Предмет</th><th>Среднее</th><th>Медиана</th><th>Количество</th><th>Распределение</th></tr></thead><tbody></tbody>`;
  const tbody2 = table2.querySelector('tbody');
  Object.keys(grouped.bySubject).sort().forEach(subj => {
    const arr = grouped.bySubject[subj].filter(v => v !== '' && !isNaN(v)).map(Number);
    const st = statsFromArray(arr);
    const tr = document.createElement('tr');
    if(!st){ tr.innerHTML = `<td>${subj}</td><td>-</td><td>-</td><td>0</td><td>-</td>`; tbody2.appendChild(tr); return; }
    const dist = Object.entries(st.counts).map(([g,c])=> `${g}:${c}, ${((c/st.count)*100).toFixed(1)}%`).join('; ');
    tr.innerHTML = `<td>${subj}</td><td>${st.mean.toFixed(2)}</td><td>${st.median}</td><td>${st.count}</td><td>${dist}</td>`;
    tbody2.appendChild(tr);
  });
  container.appendChild(table2);
}

/* --- Charts --- */
let chartInstance = null;
$('#drawChartBtn').addEventListener('click', () => {
  const cls = $('#chartClass').value;
  const subj = $('#chartSubject').value;
  const filtered = records.filter(r => (cls==='__all__' || r.Class===cls) && (subj==='__all__' || r.Subject===subj));
  const grades = filtered.map(r => Number(String(r.Grade).replace(',', '.'))).filter(v => !isNaN(v));
  if(grades.length===0){ alert('Нет числовых оценок для выбранного фильтра'); return; }
  // build distribution counts
  const counts = {};
  grades.forEach(g => {
    counts[g] = (counts[g]||0)+1;
  });
  const labels = Object.keys(counts).sort((a,b)=>Number(a)-Number(b));
  const data = labels.map(l => counts[l]);
  const ctx = document.getElementById('gradeDistributionChart').getContext('2d');
  if(chartInstance) chartInstance.destroy();
  chartInstance = new Chart(ctx, {
    type: 'bar',
    data: { labels, datasets: [{ label: 'Кол-во учеников', data }] },
    options: { responsive:true, plugins:{legend:{display:false}}}
  });
});

/* --- Sample and UI init --- */
document.getElementById('downloadSampleBtn').addEventListener('click', () => {
  const sample = `FIO,Class,Subject,Grade
Иванов Иван Иванович,9A,Математика,5
Петров Петр Петрович,9A,Математика,4
Сидорова Анна Ивановна,9B,Русский язык,5
Кузнецов Сергей Владимирович,10A,Физика,3
`;
  download('example.csv', sample);
});

function renderSamplePreview(){
  // no-op for now
}

function init(){
  refreshJournalTable();
  fillFilters();
  // load example records for demo
  const demo = [
    {id:uid(), FIO:'Иванов Иван Иванович', Class:'9A', Subject:'Математика', Grade:'5'},
    {id:uid(), FIO:'Петров Петр Петрович', Class:'9A', Subject:'Математика', Grade:'4'},
    {id:uid(), FIO:'Сидорова Анна Ивановна', Class:'9B', Subject:'Русский язык', Grade:'5'},
    {id:uid(), FIO:'Кузнецов Сергей Владимирович', Class:'10A', Subject:'Физика', Grade:'3'},
  ];
  records = records.concat(demo);
  refreshJournalTable();
  fillFilters();
}
init();